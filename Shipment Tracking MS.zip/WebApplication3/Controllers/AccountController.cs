﻿using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using ShipmentTrackingManagementSystem.Models;

public class AccountController : Controller
{
    private readonly MyContext context;
    private readonly IPasswordHasher<User> passwordHasher;


    public AccountController(MyContext context, IPasswordHasher<User> passwordHasher    )

    {
        this.context = context;
        this.passwordHasher = passwordHasher;
    }

   
    public IActionResult Login()
    {
        return View();
    }





    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(string email, string password)
    {
       
        var user = await context.Users
            .Include(u => u.Role)
            .FirstOrDefaultAsync(u => u.Email == email);

        if (user == null || user.Role == null)
        {
            ViewBag.Error = "Email or Password is incorrect";
            return View();
        }

       
        if (string.IsNullOrWhiteSpace(user.PasswordHash))
        {
            ViewBag.Error = "Email or Password is incorrect";
            return View();
        }

        PasswordVerificationResult result;

        try
        {
            result = passwordHasher.VerifyHashedPassword(
                user,
                user.PasswordHash,
                password
            );
        }
        catch (FormatException)
        {
            ViewBag.Error = "Email or Password is incorrect";
            return View();
        }

        if (result == PasswordVerificationResult.Failed)
        {
            ViewBag.Error = "Email or Password is incorrect";
            return View();
        }

       
        var claims = new List<Claim>
    {
        new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),

        new Claim(ClaimTypes.Name, user.FullName),

        new Claim(ClaimTypes.Role, user.Role.RoleName)
    };

        var identity = new ClaimsIdentity(
            claims,
            CookieAuthenticationDefaults.AuthenticationScheme
        );

        var principal = new ClaimsPrincipal(identity);

       
        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            principal
        );

       
        if (user.Role.RoleName == "Admin")
        {
            return RedirectToAction("Statistics", "Admin");
        }
        else if (user.Role.RoleName == "Employee")
        {
            return RedirectToAction("MyShipment", "Employee");
        }
        else if (user.Role.RoleName == "Customer")
        {
            return RedirectToAction("ShipmentNo", "Customer");
        }

        await HttpContext.SignOutAsync(
            CookieAuthenticationDefaults.AuthenticationScheme
        );

        return RedirectToAction("Login");
    }
    

    public IActionResult Register()
    {
        return View();
    }



    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(
    string fullName,
    string email,
    string phone,
    string password,
    string confirmPassword)
    {
        if (password != confirmPassword)
        {
            ViewBag.Error = "كلمة المرور غير متطابقة";
            return View();
        }

        var existingUser = await context.Users
            .FirstOrDefaultAsync(u => u.Email == email);

        if (existingUser != null)
        {
            ViewBag.Error = "البريد الإلكتروني مستخدم مسبقاً";
            return View();
        }

        var customerRole = await context.Roles
            .FirstOrDefaultAsync(r => r.RoleName == "Customer");

        if (customerRole == null)
        {
            ViewBag.Error = "Customer Role غير موجود";
            return View();
        }

        var user = new User
        {
            FullName = fullName,
            Email = email,
            PhoneNumber = phone,
            RoleId = customerRole.Id
        };

      
        user.PasswordHash = passwordHasher.HashPassword(
            user, password);

        context.Users.Add(user);

        await context.SaveChangesAsync();

        var customer = new Customer
        {
            UserId = user.Id,
            RegistrationDate = DateTime.Now
        };

        context.Customers.Add(customer);

        await context.SaveChangesAsync();

        return RedirectToAction("Login");
    }

}