﻿

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ShipmentTrackingManagementSystem.Models;

namespace ShipmentTrackingManagementSystem.Controllers
{
    public class AdminController : Controller
    {
        private readonly MyContext context;
        private readonly PasswordHasher<User> passwordHasher;

        public AdminController(MyContext _context)
        {
            context = _context;
            passwordHasher = new PasswordHasher<User>();
        }

       
        public IActionResult EmployeeManagment(string searchTerm)
        {
            var employees = context.Employees
                .Include(e => e.User)
                .AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                employees = employees.Where(e =>
                    e.User.FullName.Contains(searchTerm));
            }

            return View(employees.ToList());
        }

  [HttpGet]
        public IActionResult AddEmployee()
        {
            return View();
        }




        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddEmployee(Employee employee)
        {
            ModelState.Remove("User.PasswordHash");
            ModelState.Remove("User.Role");
            ModelState.Remove("User.Customer");
            ModelState.Remove("User");
            ModelState.Remove("Shipments");
            ModelState.Remove("Password");

            if (employee.User == null)
                return BadRequest();

            if (string.IsNullOrWhiteSpace(employee.Password))
            {
                ModelState.AddModelError("Password", "يرجى إدخال كلمة المرور");
            }

            if (context.Users.Any(u => u.Email == employee.User.Email))
            {
                ModelState.AddModelError("User.Email", "البريد الإلكتروني مستخدم مسبقاً");
            }

            if (!ModelState.IsValid)
            {
                return View(employee);
            }

           
            var role = context.Roles.FirstOrDefault(r => r.RoleName == "Employee");

            if (role == null)
            {
                ModelState.AddModelError("", "دور الموظف غير موجود في قاعدة البيانات");
                return View(employee);
            }

            employee.User.PasswordHash = passwordHasher.HashPassword(
                employee.User,
                employee.Password
            );

           
            employee.User.RoleId = role.Id;

           
            context.Users.Add(employee.User);
            context.SaveChanges();

           
            employee.UserId = employee.User.Id;

          
            context.Employees.Add(employee);
            context.SaveChanges();

            return RedirectToAction("EmployeeManagment");
        }

       
        [HttpGet]
        public IActionResult UpdateEmployee(int id)
        {
            var employee = context.Employees
                .Include(e => e.User)
                .FirstOrDefault(e => e.Id == id);

            if (employee == null)
                return NotFound();

            return View(employee);
        }


       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateEmployee(Employee employee)
        {
            var oldEmployee = context.Employees
                .Include(e => e.User)
                .FirstOrDefault(e => e.Id == employee.Id);

            if (oldEmployee == null)
                return NotFound();

            if (employee.User == null)
                return BadRequest();

            bool emailExists = context.Users.Any(u =>
                u.Email == employee.User.Email &&
                u.Id != oldEmployee.UserId);

            if (emailExists)
            {
                ModelState.AddModelError(
                    "User.Email",
                    "البريد الإلكتروني مستخدم مسبقاً");

                return View(oldEmployee);
            }

            oldEmployee.User.FullName = employee.User.FullName;
            oldEmployee.User.Email = employee.User.Email;
            oldEmployee.User.PhoneNumber = employee.User.PhoneNumber;

            oldEmployee.HireDate = employee.HireDate;
            oldEmployee.IsActive = employee.IsActive;

            context.SaveChanges();

            return RedirectToAction("EmployeeManagment");
        }


        [HttpGet]
        public IActionResult DeleteEmployee(int id)
        {
            var employee = context.Employees
                .Include(e => e.User)
                .FirstOrDefault(e => e.Id == id);

            if (employee == null)
                return NotFound();

            return View(employee);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteEmployeeConfirmed(int id)
        {
            var employee = context.Employees
                .Include(e => e.User)
                .FirstOrDefault(e => e.Id == id);

            if (employee == null)
                return NotFound();

            context.Employees.Remove(employee);
            context.SaveChanges();

            return RedirectToAction("EmployeeManagment");
        }



        [HttpGet]
        public async Task<IActionResult> ShipmentManagment(string search)
        {
            var shipments = context.Shipments
                .Include(s => s.Customer)
                    .ThenInclude(c => c.User)
                .Include(s => s.Employee)
                    .ThenInclude(e => e.User)
                .Include(s => s.SenderCity)
                .Include(s => s.ReceiverCity)
                .AsQueryable();

            if (!string.IsNullOrEmpty(search))
            {
                shipments = shipments.Where(s =>
                    s.TrackingNumber.Contains(search));
            }

            var result = await shipments.ToListAsync();

            return View(result);
        }
        private void LoadShipmentLists()
        {
            ViewBag.Customers = new SelectList(
                context.Customers
                    .Include(c => c.User)
                    .ToList(),
                "Id",
                "User.FullName"
            );

            ViewBag.Employees = new SelectList(
                context.Employees
                    .Include(e => e.User)
                    .Where(e => e.IsActive)
                    .ToList(),
                "Id",
                "User.FullName"
            );

            ViewBag.Cities = new SelectList(
                context.Cities.ToList(),
                "Id",
                "CityName"
            );
        }


        [HttpGet]
        public async Task<IActionResult> GetDeliveryCost(int cityId, decimal weight)
        {
            if (cityId <= 0 || weight <= 0)
            {
                return Json(new { success = false, message = "يرجى اختيار مدينة الاستلام وإدخال وزن صحيح." });
            }

            var pricing = await context.Pricings
                .FirstOrDefaultAsync(p => p.CityId == cityId && p.IsActive);

            if (pricing == null)
            {
                return Json(new { success = false, message = "لا توجد تسعيرة مفعلة لهذه المدينة." });
            }

            decimal cost = pricing.BasePrice;

            if (weight > pricing.MaxWeight)
            {
                decimal extraWeight = weight - pricing.MaxWeight;
                cost += extraWeight * pricing.AdditionalWeightPrice;
            }

            cost = Math.Round(cost, 2);

            return Json(new { success = true, cost = cost });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddShipment(Shipment shipment)
        {
            ModelState.Remove("TrackingNumber");
            ModelState.Remove("DeliveryCost");
            ModelState.Remove("CreatedAt");
            ModelState.Remove("ShipmentHistories");
            ModelState.Remove("Customer");
            ModelState.Remove("Employee");
            ModelState.Remove("SenderCity");
            ModelState.Remove("ReceiverCity");

            if (shipment.Weight <= 0)
            {
                ModelState.AddModelError("Weight", "يجب إدخال وزن صحيح للشحنة.");
            }

            if (!ModelState.IsValid)
            {
                LoadShipmentLists();
                return View(shipment);
            }

            var pricing = await context.Pricings
                .FirstOrDefaultAsync(p =>
                    p.CityId == shipment.ReceiverCityId &&
                    p.IsActive);

            if (pricing == null)
            {
                ModelState.AddModelError("ReceiverCityId", "لا توجد تسعيرة مفعلة لهذه المدينة.");
                LoadShipmentLists();
                return View(shipment);
            }

            decimal cost = pricing.BasePrice;

            if (shipment.Weight > pricing.MaxWeight)
            {
                decimal extraWeight = shipment.Weight - pricing.MaxWeight;
                cost += extraWeight * pricing.AdditionalWeightPrice;
            }

            shipment.DeliveryCost = Math.Round(cost, 2);

            string trackingNumber;
            do
            {
                trackingNumber = "SHP" +
                    DateTime.Now.ToString("yyyyMMddHHmmss") +
                    Random.Shared.Next(100, 999);
            }
            while (await context.Shipments.AnyAsync(s => s.TrackingNumber == trackingNumber));

            shipment.TrackingNumber = trackingNumber;
            shipment.CreatedAt = DateTime.Now;
            shipment.DeliveredAt = null;

            context.Shipments.Add(shipment);
            await context.SaveChangesAsync();
            context.ShipmentHistories.Add(new ShipmentHistory
            {
                ShipmentId = shipment.Id,
                Status = shipment.Status,
                UpdatedAt = DateTime.Now,
                Notes = "تم إنشاء الشحنة"
            });

            await context.SaveChangesAsync();

            TempData["Success"] = "تمت إضافة الشحنة بنجاح";

            return RedirectToAction("ShipmentManagment");
        }


        public IActionResult Statistics()
        {
           
            ViewBag.TotalShipments = context.Shipments.Count();

            ViewBag.ProcessingShipments = context.Shipments
                .Count(s => s.Status == ShipmentStatus.Processing);

            ViewBag.InTransitShipments = context.Shipments
                .Count(s => s.Status == ShipmentStatus.OutForDelivery);

            ViewBag.DeliveredShipments = context.Shipments
                .Count(s => s.Status == ShipmentStatus.Delivered);

            ViewBag.ReturnedShipments = context.Shipments
                .Count(s => s.Status == ShipmentStatus.Returned);


          
            ViewBag.TotalRevenue = context.Shipments
                .Sum(s => (decimal?)s.DeliveryCost) ?? 0;


            ViewBag.AverageCost = context.Shipments.Any()
                ? context.Shipments.Average(s => s.DeliveryCost)
                : 0;


           
            ViewBag.TotalEmployees = context.Employees.Count();

            var topEmployee = context.Shipments
                .GroupBy(s => s.EmployeeId)
                .Select(g => new
                {
                    EmployeeId = g.Key,
                    ShipmentCount = g.Count()
                })
                .OrderByDescending(g => g.ShipmentCount)
                .FirstOrDefault();

            if (topEmployee != null)
            {
                ViewBag.TopEmployee = context.Employees
                    .Where(e => e.Id == topEmployee.EmployeeId)
                    .Select(e => e.User.FullName)
                    .FirstOrDefault();
            }
            else
            {
                ViewBag.TopEmployee = "لا يوجد";
            }


           
            var topReceiverCity = context.Shipments
                .GroupBy(s => s.ReceiverCityId)
                .Select(g => new
                {
                    CityId = g.Key,
                    ShipmentCount = g.Count()
                })
                .OrderByDescending(g => g.ShipmentCount)
                .FirstOrDefault();

            ViewBag.TopReceiverCity = topReceiverCity != null
                ? context.Cities
                    .Where(c => c.Id == topReceiverCity.CityId)
                    .Select(c => c.CityName)
                    .FirstOrDefault()
                : "لا يوجد";


          
            var topSenderCity = context.Shipments
                .GroupBy(s => s.SenderCityId)
                .Select(g => new
                {
                    CityId = g.Key,
                    ShipmentCount = g.Count()
                })
                .OrderByDescending(g => g.ShipmentCount)
                .FirstOrDefault();

            ViewBag.TopSenderCity = topSenderCity != null
                ? context.Cities
                    .Where(c => c.Id == topSenderCity.CityId)
                    .Select(c => c.CityName)
                    .FirstOrDefault()
                : "لا يوجد";


            return View();
        }


        [HttpGet]
        public IActionResult AddShipment()
        {
            LoadShipmentLists();

            return View();
        }
       
        [HttpGet]
        public async Task<IActionResult> UpdateShipment(int id)
        {
            var shipment = await context.Shipments
                .FirstOrDefaultAsync(s => s.Id == id);

            if (shipment == null)
                return NotFound();

            LoadShipmentLists();

            return View(shipment);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateShipment(int id, Shipment shipment)
        {
            ModelState.Remove("TrackingNumber");
            ModelState.Remove("Customer");
            ModelState.Remove("Employee");
            ModelState.Remove("SenderCity");
            ModelState.Remove("ReceiverCity");
            ModelState.Remove("ShipmentHistories");

            if (!ModelState.IsValid)
            {
                LoadShipmentLists();
                return View(shipment);
            }

            if (shipment.Weight <= 0)
            {
                ModelState.AddModelError(
                    "Weight",
                    "يجب إدخال وزن صحيح للشحنة");

                LoadShipmentLists();
                return View(shipment);
            }

            var existingShipment = await context.Shipments
                .FirstOrDefaultAsync(s => s.Id == id);

            if (existingShipment == null)
                return NotFound();

            var pricing = await context.Pricings
                .FirstOrDefaultAsync(p =>
                    p.CityId == shipment.ReceiverCityId &&
                    p.IsActive);

            if (pricing == null)
            {
                ModelState.AddModelError(
                    "ReceiverCityId",
                    "لا توجد تسعيرة مفعلة لهذه المدينة");

                LoadShipmentLists();
                return View(shipment);
            }

            decimal cost = pricing.BasePrice;

            if (shipment.Weight > pricing.MaxWeight)
            {
                decimal extraWeight =
                    shipment.Weight - pricing.MaxWeight;

                cost += extraWeight * pricing.AdditionalWeightPrice;
            }

            existingShipment.CustomerId = shipment.CustomerId;
            existingShipment.EmployeeId = shipment.EmployeeId;

            existingShipment.Description = shipment.Description;

            existingShipment.Weight = shipment.Weight;
            existingShipment.DeliveryCost = cost;

            existingShipment.Status = shipment.Status;

            existingShipment.ExpectedDeliveryDate =
                shipment.ExpectedDeliveryDate;

            existingShipment.Notes = shipment.Notes;

            existingShipment.SenderName = shipment.SenderName;
            existingShipment.SenderPhone = shipment.SenderPhone;
            existingShipment.SenderCityId = shipment.SenderCityId;

            existingShipment.ReceiverName = shipment.ReceiverName;
            existingShipment.ReceiverPhone = shipment.ReceiverPhone;
            existingShipment.ReceiverAddress = shipment.ReceiverAddress;
            existingShipment.ReceiverCityId = shipment.ReceiverCityId;

            if (shipment.Status == ShipmentStatus.Delivered)
            {
                if (existingShipment.DeliveredAt == null)
                    existingShipment.DeliveredAt = DateTime.Now;
            }
            else
            {
                existingShipment.DeliveredAt = null;
            }

            await context.SaveChangesAsync();

            TempData["Success"] = "تم تعديل الشحنة بنجاح";

            return RedirectToAction("ShipmentManagment");
        }
        [HttpGet]
        public async Task<IActionResult> ShipmentDetails(int id)
        {
            var shipment = await context.Shipments
                .Include(s => s.Customer)
                    .ThenInclude(c => c.User)
                .Include(s => s.Employee)
                    .ThenInclude(e => e.User)
                .Include(s => s.SenderCity)
                .Include(s => s.ReceiverCity)
                .Include(s => s.ShipmentHistories)
                .FirstOrDefaultAsync(s => s.Id == id);

            if (shipment == null)
                return NotFound();

            return View(shipment);
        }
        [HttpGet]
        public async Task<IActionResult> DeleteShipment(int id)
        {
            var shipment = await context.Shipments
                .Include(s => s.Customer)
                    .ThenInclude(c => c.User)
                .Include(s => s.Employee)
                    .ThenInclude(e => e.User)
                .Include(s => s.SenderCity)
                .Include(s => s.ReceiverCity)
                .FirstOrDefaultAsync(s => s.Id == id);

            if (shipment == null)
                return NotFound();

            return View(shipment);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteShipmentConfirmed(int id)
        {
            var shipment = await context.Shipments
                .Include(s => s.ShipmentHistories)
                .FirstOrDefaultAsync(s => s.Id == id);

            if (shipment == null)
                return NotFound();

            context.ShipmentHistories.RemoveRange(
                shipment.ShipmentHistories);

            context.Shipments.Remove(shipment);

            await context.SaveChangesAsync();

            TempData["Success"] = "تم حذف الشحنة بنجاح";

            return RedirectToAction("ShipmentManagment");
        }
    }
}



