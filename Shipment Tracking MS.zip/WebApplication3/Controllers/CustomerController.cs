﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShipmentTrackingManagementSystem.Models;

namespace ShipmentTrackingManagementSystem.Controllers
{
    //[Authorize(Roles = "Customer")]
    public class CustomerController : Controller
    {

        private readonly MyContext context;
       
        public CustomerController(MyContext _context)
        {
            context = _context;
           
        }
        [HttpGet]
        public IActionResult ShipmentNo()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> ShipmentDe(string trackingNumber)
        {
            if (string.IsNullOrWhiteSpace(trackingNumber))
            {
                ViewBag.Error = "الرجاء إدخال رقم التتبع";
                return View("ShipmentNo");
            }

            trackingNumber = trackingNumber.Trim();

            var shipment = await context.Shipments
                .Include(s => s.SenderCity)
                .Include(s => s.ReceiverCity)
                .FirstOrDefaultAsync(s => s.TrackingNumber == trackingNumber);

            if (shipment == null)
            {
                ViewBag.Error = "رقم التتبع غير موجود، الرجاء التأكد من الرقم والمحاولة مرة أخرى.";
                return View("ShipmentNo");
            }

            return View(shipment);
        }
    }
}
