﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ShipmentTrackingManagementSystem.Models;
using System.Drawing;
using System.Security.Claims;

namespace ShipmentTrackingManagementSystem.Controllers
{
    //[Authorize(Roles = "Employee")]
    public class EmployeeController : Controller
    {
        private readonly MyContext context;

        public EmployeeController(MyContext context)
        {
            this.context = context;
        }

       
        private async Task<Employee?> GetCurrentEmployee()
        {
            var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int userId))
                return null;

            return await context.Employees
                .FirstOrDefaultAsync(e => e.UserId == userId);
        }

       
        public async Task<IActionResult> MyShipment()
        {
            var employee = await GetCurrentEmployee();

            if (employee == null)
                return NotFound("الموظف غير موجود");

            var shipments = await context.Shipments
                .Include(s => s.SenderCity)
                .Include(s => s.ReceiverCity)
                .Where(s => s.EmployeeId == employee.Id)
                .OrderByDescending(s => s.CreatedAt)
                .ToListAsync();

            return View(shipments);
        }

       

        public async Task<IActionResult> MyShipmentDetails(int id)
        {
           
            var userId = int.Parse(
                User.FindFirstValue(ClaimTypes.NameIdentifier)
            );

           
            var employee = await context.Employees
                .FirstOrDefaultAsync(e => e.UserId == userId);

            if (employee == null)
            {
                return NotFound();
            }

           
            var shipment = await context.Shipments
                .Include(s => s.SenderCity)
                .Include(s => s.ReceiverCity)
                .FirstOrDefaultAsync(s =>
                    s.Id == id &&
                    s.EmployeeId == employee.Id
                );

            if (shipment == null)
            {
                return NotFound();
            }

            return View(shipment);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateShipmentStatus(
    int id,
    ShipmentStatus newStatus,
    string? note)
        {
           
            var userId = int.Parse(
                User.FindFirstValue(ClaimTypes.NameIdentifier)
            );

            
            var employee = await context.Employees
                .FirstOrDefaultAsync(e => e.UserId == userId);

            if (employee == null)
            {
                return NotFound();
            }

           
            if (!Enum.IsDefined(typeof(ShipmentStatus), newStatus))
            {
                return BadRequest();
            }

           
            var shipment = await context.Shipments
                .FirstOrDefaultAsync(s =>
                    s.Id == id &&
                    s.EmployeeId == employee.Id
                );

            if (shipment == null)
            {
                return NotFound();
            }

           
            if (shipment.Status == newStatus)
            {
                TempData["Success"] = "الشحنة موجودة بالفعل في هذه الحالة.";

                return RedirectToAction(
                    "MyShipmentDetails",
                    new { id = id }
                );
            }

          
            shipment.Status = newStatus;
            if (newStatus == ShipmentStatus.Delivered)
            {
                shipment.DeliveredAt = DateTime.Now;
            }

           
            var history = new ShipmentHistory
            {
                ShipmentId = shipment.Id,

                Status = newStatus,

                UpdatedAt = DateTime.Now,

                Notes = note,

                EmployeeId = employee.Id
            };

            context.ShipmentHistories.Add(history);

           
            await context.SaveChangesAsync();

            TempData["Success"] = "تم تحديث حالة الشحنة بنجاح.";

            return RedirectToAction(
                "MyShipmentDetails",
                new { id = id }
            );
        }


        public async Task<IActionResult> ShipmentHistory(int id)
        {
           
            var userId = int.Parse(
                User.FindFirstValue(ClaimTypes.NameIdentifier)
            );

            
            var employee = await context.Employees
                .FirstOrDefaultAsync(e => e.UserId == userId);

            if (employee == null)
            {
                return NotFound();
            }

           
            var shipment = await context.Shipments
                .Include(s => s.ReceiverCity)
                .FirstOrDefaultAsync(s =>
                    s.Id == id &&
                    s.EmployeeId == employee.Id
                );

            if (shipment == null)
            {
                return NotFound();
            }

           
            var history = await context.ShipmentHistories
                .Where(h => h.ShipmentId == id)
                .OrderByDescending(h => h.UpdatedAt)
                .ToListAsync();

          
            ViewBag.Shipment = shipment;

            return View("MyShipmentHistory",history);
        }



        private void LoadCities()
        {
            var cities = context.Cities.ToList();

            ViewBag.Cities = cities;

            Console.WriteLine("عدد المدن: " + cities.Count);

            foreach (var city in cities)
            {
                Console.WriteLine($"ID: {city.Id} - Name: {city.CityName}");
            }
        }

        public IActionResult PriceManagment()
        {
            var prices = context.Pricings
                .Include(p => p.City)
                .ToList();

            LoadCities();

            return View(prices);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddPrice(Pricing price)
        {
          
            var receivedCityId = Request.Form["CityId"].ToString();

           
            var receivedCity = price.CityId;
           
            var cityExists = context.Cities
                .Any(c => c.Id == price.CityId);
            var selectedCity = context.Cities
    .FirstOrDefault(c => c.Id == price.CityId);
           
            if (context.Pricings.Any(p => p.CityId == price.CityId))
            {
                ModelState.AddModelError(
                    "CityId",
                    "توجد تسعيرة مسجلة لهذه المدينة بالفعل"
                );
            }
  if (!ModelState.IsValid || !cityExists)
            {
                var prices = context.Pricings
                    .Include(p => p.City)
                    .ToList();

                LoadCities();

                ViewBag.ErrorMessage = string.Join(" | ",
                    ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage));

                return View("PriceManagment", prices);
            }

            try
            {
                context.Pricings.Add(price);

                context.SaveChanges();

                return RedirectToAction("PriceManagment");
            }
            catch (Exception ex)
            {
                var prices = context.Pricings
                    .Include(p => p.City)
                    .ToList();

                LoadCities();

                ViewBag.ErrorMessage =
                    ex.InnerException?.Message ?? ex.Message;

                return View("PriceManagment", prices);
            }
        }


        [HttpGet]
        public IActionResult UpdatePrice(int id)
        {
            var price = context.Pricings
                .Include(p => p.City)
                .FirstOrDefault(p => p.Id == id);

            if (price == null)
                return NotFound();

            return View("UpdatePrice", price);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdatePrice(Pricing price)
        {
            var oldPrice = context.Pricings
                .FirstOrDefault(p => p.Id == price.Id);

            if (oldPrice == null)
                return NotFound();

            if (price.MaxWeight <= 0 ||
                price.AdditionalWeightPrice < 0)
            {
                ModelState.AddModelError(
                    "",
                    "يرجى إدخال قيم صحيحة"
                );

                oldPrice.City = context.Cities
                    .FirstOrDefault(c => c.Id == oldPrice.CityId);

                return View("UpdatePrice", oldPrice);
            }

            oldPrice.MaxWeight = price.MaxWeight;
            oldPrice.AdditionalWeightPrice = price.AdditionalWeightPrice;
            oldPrice.IsActive = price.IsActive;

            context.SaveChanges();

            return RedirectToAction("PriceManagment");
        }

        [HttpGet]
        public IActionResult DeletePrice(int id)
        {
            var price = context.Pricings
                .Include(p => p.City)
                .FirstOrDefault(p => p.Id == id);

            if (price == null)
                return NotFound();

            return View("DeletePrice", price);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ConfirmDeletePrice(int id)
        {
            var price = context.Pricings
                .FirstOrDefault(p => p.Id == id);

            if (price == null)
                return NotFound();

            context.Pricings.Remove(price);

            context.SaveChanges();

            return RedirectToAction("DeletePrice");
        }



    } }