﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ShipmentTrackingManagementSystem.Migrations
{
    /// <inheritdoc />
    public partial class zMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
