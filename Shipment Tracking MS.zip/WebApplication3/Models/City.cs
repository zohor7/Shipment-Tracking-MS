﻿namespace ShipmentTrackingManagementSystem.Models
{
    public class City
    {
        public int Id { get; set; }

        public string CityName { get; set; }

        public ICollection<Shipment> SenderShipments { get; set; }

        public ICollection<Shipment> ReceiverShipments { get; set; }

    }
}
