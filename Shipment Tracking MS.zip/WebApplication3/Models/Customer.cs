﻿namespace ShipmentTrackingManagementSystem.Models
{
    public class Customer
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public DateTime RegistrationDate { get; set; }

        public User User { get; set; }

       
        public ICollection<Shipment> Shipments { get; set; } = new List<Shipment>();

    }
}
