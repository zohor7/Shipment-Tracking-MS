﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ShipmentTrackingManagementSystem.Models
{
    public class Employee
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public DateTime HireDate { get; set; }

        public bool IsActive { get; set; }

        public User User { get; set; }
        [NotMapped]
        public string Password { get; set; }

        public ICollection<Shipment> Shipments { get; set; } = new List<Shipment>();
    }
}
