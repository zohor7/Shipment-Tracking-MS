﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ShipmentTrackingManagementSystem.Models;

namespace ShipmentTrackingManagementSystem.Models
{
    public class MyContext : DbContext
    {
        public MyContext(DbContextOptions<MyContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }

        public DbSet<Role> Roles { get; set; }

        public DbSet<Employee> Employees { get; set; }

        public DbSet<Customer> Customers { get; set; }

        public DbSet<City> Cities { get; set; }

        public DbSet<Pricing> Pricings { get; set; }

        public DbSet<Shipment> Shipments { get; set; }

        public DbSet<ShipmentHistory> ShipmentHistories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // City - Sender
            modelBuilder.Entity<Shipment>()
                .HasOne(s => s.SenderCity)
                .WithMany(c => c.SenderShipments)
                .HasForeignKey(s => s.SenderCityId)
                .OnDelete(DeleteBehavior.NoAction);

            // City - Receiver
            modelBuilder.Entity<Shipment>()
                .HasOne(s => s.ReceiverCity)
                .WithMany(c => c.ReceiverShipments)
                .HasForeignKey(s => s.ReceiverCityId)
                .OnDelete(DeleteBehavior.NoAction);

            // Employee - Shipment
            modelBuilder.Entity<Shipment>()
                .HasOne(s => s.Employee)
                .WithMany(e => e.Shipments)
                .HasForeignKey(s => s.EmployeeId)
                .OnDelete(DeleteBehavior.NoAction);

            modelBuilder.Entity<Customer>()
    .HasOne(c => c.User)
    .WithOne(u => u.Customer)
    .HasForeignKey<Customer>(c => c.UserId);

            // Shipment - ShipmentHistory
            modelBuilder.Entity<ShipmentHistory>()
                .HasOne(h => h.Shipment)
                .WithMany(s => s.ShipmentHistories)
                .HasForeignKey(h => h.ShipmentId)
                .OnDelete(DeleteBehavior.NoAction);

            // Employee - ShipmentHistory
            modelBuilder.Entity<ShipmentHistory>()
                .HasOne(h => h.Employee)
                .WithMany()
                .HasForeignKey(h => h.EmployeeId)
                .OnDelete(DeleteBehavior.NoAction);

           
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.User)
                .WithOne()
                .HasForeignKey<Employee>(e => e.UserId);


            modelBuilder.Entity<Pricing>()
    .HasOne(p => p.City)
    .WithMany()
    .HasForeignKey(p => p.CityId);

        }
    }
}