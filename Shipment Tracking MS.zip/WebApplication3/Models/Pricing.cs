﻿namespace ShipmentTrackingManagementSystem.Models
{
    public class Pricing
    {
        public int Id { get; set; }

        public int? CityId { get; set; }

        public decimal BasePrice { get; set; }

        public decimal MaxWeight { get; set; }

        public decimal AdditionalWeightPrice { get; set; }

        public bool IsActive { get; set; }

        public City? City { get; set; }
    }
}
