﻿namespace ShipmentTrackingManagementSystem.Models
{
    public class Shipment
    {
        public int Id { get; set; }

        public string? TrackingNumber { get; set; }

        public int CustomerId { get; set; }

        public int EmployeeId { get; set; }

        public int SenderCityId { get; set; }

        public int ReceiverCityId { get; set; }

        public string SenderName { get; set; }

        public string SenderPhone { get; set; }

        public string ReceiverName { get; set; }

        public string ReceiverPhone { get; set; }

        public string ReceiverAddress { get; set; }

        public string Description { get; set; }

        public decimal Weight { get; set; }

        public decimal DeliveryCost { get; set; }

        public ShipmentStatus Status { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime? DeliveredAt { get; set; }

        public DateTime? ExpectedDeliveryDate { get; set; }

        public string? Notes { get; set; }

        // Navigation Properties

        public Customer? Customer { get; set; }

        public Employee? Employee { get; set; }

        public City? SenderCity { get; set; }

        public City? ReceiverCity { get; set; }
        public ICollection<ShipmentHistory> ShipmentHistories { get; set; }
    = new List<ShipmentHistory>();
    }
}
