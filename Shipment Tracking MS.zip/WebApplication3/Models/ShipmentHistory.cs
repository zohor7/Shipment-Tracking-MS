﻿namespace ShipmentTrackingManagementSystem.Models
{
    public class ShipmentHistory
    {
        public int Id { get; set; }

        public int ShipmentId { get; set; }

        public ShipmentStatus Status { get; set; }

        public DateTime UpdatedAt { get; set; }

      
        public string? Notes { get; set; }

        public int? EmployeeId { get; set; }

        public Shipment Shipment { get; set; }

        public Employee? Employee { get; set; }
    }
}
