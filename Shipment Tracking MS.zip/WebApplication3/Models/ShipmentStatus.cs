﻿namespace ShipmentTrackingManagementSystem.Models
{
    public enum ShipmentStatus
    {
        Processing = 1,
        OutForDelivery = 2,
        Delivered = 3,
        Returned = 4
    }
}
