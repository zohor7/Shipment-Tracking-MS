﻿using System.Data;

namespace ShipmentTrackingManagementSystem.Models
{
    public class User
    {
        public int Id { get; set; }
       
        public string FullName { get; set; }

        public string Email { get; set; }

        public string PasswordHash { get; set; }

        public string PhoneNumber { get; set; }

        public int RoleId { get; set; }

        public Role Role { get; set; }
        public Customer Customer { get; set; }
    }
}
