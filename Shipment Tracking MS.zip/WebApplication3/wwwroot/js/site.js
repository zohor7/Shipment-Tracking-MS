﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
//document.addEventListener('DOMContentLoaded', function () {
//    const form = document.getElementById('inquiryForm');

//    if (form) {
//        form.addEventListener('submit', function (e) {
//            e.preventDefault();

//            // Get form data
//            const formData = {
//                name: document.getElementById('name').value.trim(),
//                email: document.getElementById('email').value.trim(),
//                subject: document.getElementById('subject').value.trim(),
//                message: document.getElementById('message').value.trim()
//            };

//            // Simple validation
//            if (!formData.name || !formData.email || !formData.subject || !formData.message) {
//                showMessage('الرجاء ملء جميع الحقول المطلوبة', 'error');
//                return;
//            }

//            // Email validation
//            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//            if (!emailRegex.test(formData.email)) {
//                showMessage('الرجاء إدخال بريد إلكتروني صحيح', 'error');
//                return;
//            }

//            // Show loading state
//            const submitButton = form.querySelector('.submit-btn');
//            const originalButtonText = submitButton.textContent;
//            submitButton.disabled = true;
//            submitButton.textContent = 'جاري الإرسال...';
//            submitButton.style.opacity = '0.7';

//            // Simulate form submission (replace with actual API call)
//            setTimeout(() => {
//                // Here you would typically make an AJAX request to your server
//                console.log('Form submitted:', formData);

//                // Show success message
//                showMessage('تم إرسال استفسارك بنجاح! سنتواصل معك قريباً.', 'success');

//                // Reset form
//                form.reset();

//                // Reset button state
//                submitButton.disabled = false;
//                submitButton.textContent = originalButtonText;
//                submitButton.style.opacity = '1';
//            }, 1500);
//        });
//    }

//    // Function to show messages
//    function showMessage(message, type) {
//        // Remove any existing messages
//        const existingMessage = document.querySelector('.form-message');
//        if (existingMessage) {
//            existingMessage.remove();
//        }

//        // Create message element
//        const messageDiv = document.createElement('div');
//        messageDiv.className = `form-message ${type}`;
//        messageDiv.textContent = message;

//        // Style the message
//        messageDiv.style.padding = '12px';
//        messageDiv.style.marginBottom = '20px';
//        messageDiv.style.borderRadius = '6px';
//        messageDiv.style.textAlign = 'center';
//        messageDiv.style.fontWeight = '500';

//        if (type === 'error') {
//            messageDiv.style.backgroundColor = '#fee2e2';
//            messageDiv.style.color = '#dc2626';
//            messageDiv.style.border = '1px solid #fca5a5';
//        } else {
//            messageDiv.style.backgroundColor = '#dcfce7';
//            messageDiv.style.color = '#16a34a';
//            messageDiv.style.border = '1px solid #86efac';
//        }

//        // Insert the message after the form title
//        const formTitle = document.querySelector('h1');
//        if (formTitle) {
//            formTitle.parentNode.insertBefore(messageDiv, formTitle.nextSibling);
//        } else {
//            form.prepend(messageDiv);
//        }

//        // Auto-remove the message after 5 seconds
//        setTimeout(() => {
//            messageDiv.style.opacity = '0';
//            messageDiv.style.transition = 'opacity 0.5s ease';
//            setTimeout(() => messageDiv.remove(), 500);
//        }, 5000);
//    }
//});
